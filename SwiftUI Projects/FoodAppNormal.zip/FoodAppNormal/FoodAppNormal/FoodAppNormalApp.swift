//
//  FoodAppNormalApp.swift
//  FoodAppNormal
//
//  Created by admin on 8/28/23.
//

import SwiftUI

@main
struct FoodAppNormalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
