//
//  Tic_Tac_ToeApp.swift
//  Tic Tac Toe
//
//  Created by admin on 10/10/23.
//

import SwiftUI

@main
struct Tic_Tac_ToeApp: App {    
    var body: some Scene {
        WindowGroup {
            FirstPersonSignUp()
//            SecondPersonSignUp()
//            GameView(isSinglePlayerMatch: true)
        }
    }
}
