//
//  MacTicTacToeApp.swift
//  MacTicTacToe
//
//  Created by admin on 10/18/23.
//

import SwiftUI

@main
struct MacTicTacToeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
