//
//  Tic_Tac_ToeApp.swift
//  WatchTicTacToe WatchKit Extension
//
//  Created by admin on 10/16/23.
//

import SwiftUI
import UserNotifications

@main
struct Tic_Tac_ToeApp: App {
    
    @SceneBuilder var body: some Scene {
        WindowGroup {
            NavigationView {
                ContentView()
//                LandingPage()
            }
        }
    }
}
