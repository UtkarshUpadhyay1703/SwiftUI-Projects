//
//  FoodApplicationLocalizationApp.swift
//  FoodApplicationLocalization
//
//  Created by admin on 8/23/23.
//

import SwiftUI

@main
struct FoodApplicationLocalizationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
