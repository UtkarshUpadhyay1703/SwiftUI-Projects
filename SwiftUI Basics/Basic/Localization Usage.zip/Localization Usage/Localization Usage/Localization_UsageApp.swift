//
//  Localization_UsageApp.swift
//  Localization Usage
//
//  Created by admin on 8/21/23.
//

import SwiftUI

@main
struct Localization_UsageApp: App {
    var body: some Scene {
        WindowGroup {
//            ContentView()
//            English_Hindi()
//            Pluralization()
//            AutomaticGrammarAgreement()
//            TranslateApiTest()
            ImageTest()
        }
    }
}
